This is a theme based on Arc-Dark by horst3180 so credits where credits are due.
The original Arc-Dark theme kan be found here: https://github.com/horst3180/Arc-theme


Arc-Dark-Greenifyed
A said a theme based on Arc-Dark but with my own spin on it and with an "greenish" accentcolor that would work with both my own wallpaper wich can be found in the files, and with the Zafiro icontheme. I choose the Zafiro icons because of their kind ow "washed out colors" wich I think goes well with the whole feel of the theme. I created this theme for my self and to fitt my needs. I won´ t doing any updates and changes to it. Feel free to use it as you see fit. The icons used in my sidebar is application launhers in xfcepanel with modified icons from the Zafiro icon theme and can be found in the "zafiro icon mod" folder.

Zafiro icons used in this theme can be found here: https://www.opendesktop.org/p/1209330/


Usage
Dowload the files and copy thmefolder to ~/.themes for your user only or in /usr/share/themes for system wide usage. As for the Zafiro icontheme follow the instructions from creator in the link I provided apove. The moded icons can be placed any where and the just link to the icon when you create the application launcher.















